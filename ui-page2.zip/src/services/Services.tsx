
"use client"

import config from "@/config/config";


export abstract class ApiServices{
  private  static BaseUrl:string = config.baseUrl;

  // static init (baseUrl:string){
  //   this.BaseUrl=baseUrl;
  // }
  private static getHeaders(): HeadersInit {
    return {
      "Content-Type": "application/json",
    };
  }

   static async errorHandling<T>(response: Response):Promise<T>{
    if(!response.ok){
        const message=await response.text();
        throw new Error(message ||"Something went wrong")

    }
      return response.json() as Promise<T>;
   }

   static async fetchData<T>(endpoint:string):Promise<T>{
    const res=await fetch(`${this.BaseUrl}${endpoint}`);
    return this.errorHandling<T>(res);
  }

static async addData<T>(endpoint:string,data:Partial<T>):Promise<T>{

    const res=await fetch(`${this.BaseUrl}${endpoint}`,{
        method:"POST",
        headers:this.getHeaders(),
         body: JSON.stringify(data)
    })
    return this.errorHandling<T>(res);
 }


 static async updateData<T>(endpoint:string,id:number,data:Partial<T>):Promise<T>{
    const res=await fetch(`${this.BaseUrl}${endpoint}/${id}`,{
        method:"PUT",
        headers:this.getHeaders(),
        body:JSON.stringify(data)
    })
    return this.errorHandling<T>(res);
 }


 static async deleteData<T>(endpont:string,id?:number):Promise<T>{
    const res=await fetch(`${this.BaseUrl}${endpont}/${id}`,{
        method:"DELETE",
        headers:this.getHeaders(),
    })
    const result = this.errorHandling<T>(res);
    console.log("result",await result)
    return result;
    return this.errorHandling<T>(res);
 }

}
