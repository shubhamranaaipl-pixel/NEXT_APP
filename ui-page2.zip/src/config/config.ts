

interface Config {
  baseUrl: string;
  productKey:string;
  
}

const config: Config = {
  baseUrl:(process.env.NEXT_PUBLIC_BASE_URL || ""),
  productKey: process.env.NEXT_PUBLIC_URL || "",
 
};

export default config;