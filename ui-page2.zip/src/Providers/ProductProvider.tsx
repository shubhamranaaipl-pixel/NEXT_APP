"use client";
import config from "@/config/config";
import { ApiServices } from "../services/Services";
import { IProducts } from "@/types/IProduct";

export class ProductProvider extends ApiServices{
    // static{
    //     ApiServices.init(config.baseUrl);
     
    // }
   static async fetchProducts():Promise<IProducts[]>{
    return this.fetchData<IProducts[]>(config.productKey);
  }

   static async addProducts(data:Partial<IProducts[]>):Promise<IProducts[]>{
    return this.addData<IProducts[]>(config.productKey,data);
   }

   static async updateProducts(id:number,data:Partial<IProducts[]>):Promise<IProducts[]>{
    return this.updateData<IProducts[]>(config.productKey,id,data);
   }

   static async removeData(id:number):Promise<IProducts[]>{
    return this.deleteData<IProducts[]>(config.productKey,id)
   }

}