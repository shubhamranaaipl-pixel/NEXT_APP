
"use client";
import { useEffect, useState } from "react";
import "./products.scss"

import {IProducts} from "../../types/IProduct"
import { ProductProvider } from "@/Providers/ProductProvider";
import { imageurl } from "@/constants/imageurl";


export default function Product(){

const [products,setproducts]=useState<IProducts[]>([]);

const addData=async()=>{
    try{
        const newProduct =await ProductProvider.addProducts({
            title:"Mens Clothing",
            price:5000,
            category:"Men Clothing",
            image:imageurl

        })
        setproducts((prev)=>[...prev,newProduct])
    }catch(err){
        console.log(err);
    }
}
const removeData=async(id:number)=>{
    // console.log("Remove function 1")
    try{
  await ProductProvider.removeData(id);
   setproducts((prev)=>prev.filter(p=>p.id !== id))
//    console.log("Remove function 2")
    }
    catch(err){
        console.log(err)
    }
   
}

const updateProduct=async(id:number)=>{
    // console.log(id)
 try{
    const updateProd=  await ProductProvider.updateProducts(id,{
        price:4000,
        title:"Style hand bag for women",
        category:"Women Clothing"
   })
   setproducts(prev=>prev.map(prod=>prod.id === id?updateProd:prod))
 }
 catch(err){
    console.log(err)
 }


}

useEffect(()=>{
 ProductProvider.fetchProducts().then(setproducts)
 .catch(console.error)

},[])


    return(
        <main className="main_container">
        {products.map((product,index)=>(
            <div key={`${product.id}-${index}`}className="main_container_product">
          <img src={product?.image} alt={product?.title} 
          className="main_container_product_img"/>
            <h3 className="main_container_product_title">Title:{product?.title ?? ''}</h3>
            <h2 className="main_container_product_price">Price :${product?.price}</h2>
            <h4 className="main_container_product_category">Category:{product?.category}</h4>


            <button className="main_container_product_button" onClick={addData}>Add Data</button>
            <button className="main_container_product_button" onClick={()=>removeData(product?.id)}>Delete Data</button>

            <button className="main_container_product_button" onClick={()=>updateProduct(product?.id)}>Update PRoducts</button>
            </div>
        ))}
        </main>
    )
}