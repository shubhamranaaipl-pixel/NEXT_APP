"use client"
import "./header.scss"

import Image from "next/image"
import Link from "next/link"
import  logo from "../../../public/download.jpeg"
import {homeurl,carturl,contacturl,abouturl} from "../../constants/nav"
export default function Header(){
    return(
      <header className="header__container">
         <Image  className="header__container__logo"
        src={logo}
        alt="Not Found"
        width={200}
        height={200}
        />
        <input type="text"  placeholder="Search..." className="header__container__search_bar"/>
        <ul className="header__container_navs">
         <li> <Link href={homeurl} className="header__container_navs__links">Home</Link></li>
        <li><Link href={abouturl}
          className="header__container_navs__links">About</Link></li>

          <li><Link href={contacturl}
          className="header__container_navs__links">Contact</Link></li>

          <li><Link href={carturl}
          className="header__container_navs__links"> Cart</Link></li>
        </ul>
      </header>
    )
}