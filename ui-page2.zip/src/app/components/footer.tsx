import "./footer.scss"
export default  function Footer(){
    return(
     <footer className="footer_container">
        <h1 className="footer_container_heading">THANKS FOR CHOOSING US</h1>
            <h3 className="footer_contaner_web">www.mywebsite.com</h3>
     </footer>
    )
}