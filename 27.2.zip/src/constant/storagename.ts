export const LOCAL_CART="cart";
export const LOCAL_WHISHLIST="whishlist"