"use client";

import { createContext ,useEffect,useReducer} from "react";
import { ICounterState } from "./IGlobalInterface";
import {LOCAL_CART,LOCAL_WHISHLIST} from "../constant/storagename"
import IProducts from "@/types/IProducts";
import Wishlist from "@/app/wishlist/page";
import { API_URL } from "@/Api/product";



export const GlobalContext =createContext<ICounterState|null>(null);

const intialState={
  product:[],
  cart:[],
  whishlist:[],
}

export const GlobalProvider =({children}:{children:React.ReactNode})=>{

  const reducerfn=(state,action)=>{
    console.log("action",action)
      switch (action.type){
        case "FetchSucces":
          return{
            ...state,
            product:action.payload,
          }

      case "CartData":
        return{
          ...state,
          cart:action.payload,
        }
        case "whishlist":
          return{
            ...state,
            whishlist:action.payload,
          }
         
        case "FetchWhishlist":
            return{
              ...state,
              whishlist:action.payload,
            }

        case "FetchCart":
          return {
            ...state,
            cart:action.payload,
          }    
        case "Like_item":
          
          const LikeItem=state.whishlist.some((t:IProducts)=>t.id === action.payload.id);
          console.log(LikeItem)
          if(!LikeItem){
            console.log(" Like Button Clicked ")
          state.whishlist.push({...action.payload,isLiked: true});
       
        }
         

          localStorage.setItem(LOCAL_WHISHLIST,JSON.stringify(state.whishlist));

         
       

          return state;
     

         case "AddTocart":
          const cartItem=state.cart.some((t:IProducts)=>t.id === action.payload.id);
          if(!cartItem){
            state.cart.push(action.payload);
          }
          else{
            console.log("Clicked Again")
          }

          localStorage.setItem(LOCAL_CART,JSON.stringify(state.cart));
          return state;
      }
  }  

  const [state,dispatch]=useReducer(reducerfn,intialState);
    

  useEffect(() => {
   const cartItem=localStorage.getItem(LOCAL_CART);
   const localcartdata=cartItem? JSON.parse(cartItem) :[];
   dispatch({type:"FetchCart" ,payload:localcartdata})


   const whishlist=localStorage.getItem(LOCAL_WHISHLIST);
   const localwhishlist=whishlist? JSON.parse(whishlist):[];
   dispatch({type:"FetchWhishlist" ,payload:localwhishlist})

    async function FetchData() {
      const res = await fetch(API_URL);
      const data = await res.json();
      dispatch({ type: "FetchSucces", payload: data });
    }
    FetchData();
  }, []);
   
    return(
    <GlobalContext.Provider value={{state,dispatch}}>
       {children}
    </GlobalContext.Provider>
    )
}



