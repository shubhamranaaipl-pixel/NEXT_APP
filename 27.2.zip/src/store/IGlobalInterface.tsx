import IProducts from "@/types/IProducts";

type State={
     product:[],
   cart:[],
   whishlist:[],
}

 type Action = {
  type: string;
  payload?: any; 
 }
export interface ICounterState{
   state:State
  dispatch :(action: Action) => void;
}