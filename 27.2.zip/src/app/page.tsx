"use client"
import ShoppingPage from "@/components/shopingpage";


export default function Home() {
  return (
   <>
   
         <ShoppingPage/>
   </> 
  );
}
