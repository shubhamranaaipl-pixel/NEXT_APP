"use client";

import "./globalData.scss"
import { useContext } from "react";
import { GlobalContext } from "@/store/Globalcontext";
import { LOCAL_PRODUCT } from "@/constant/storagename";


export default function LikeItem(){

    const globaldata=useContext(GlobalContext);
    console.log(globaldata?.count);
    const data=globaldata?.count;
  

    const Deleteitem=(id:number)=>{
       const filterdata=data?.filter(item=>item.id !== id);
       console.log(filterdata);
       localStorage.setItem(LOCAL_PRODUCT,JSON.stringify(filterdata));
       globaldata?.setcount(filterdata??[])

    }
    return (
        <>
        <h1 className="container_heading">Global Data Page</h1>
     <main className="card_container">  
      {data?.map((item,index)=>(
        <div key={index} className="card_container_cards">
            <img src={item.image} alt={item.title} className="card_container_cards_image"/>
            <h4 className="card_container_cards_title">Title:{item.title}</h4>
            <button className="card_container_cards_button" onClick={()=>Deleteitem(item.id)}>Remove</button>
        </div>
      ))} 
     
     </main>
     </>
    )
}