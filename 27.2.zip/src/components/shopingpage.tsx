"use client";

import { useEffect} from "react";
import IProducts from "@/types/IProducts";
import { API_URL } from "@/Api/product";
import "./shoping.scss";
import { useContext } from "react";
import { GlobalContext } from "@/store/Globalcontext";
import Header from "./header";


export default function ShoppingPage() {
  const context = useContext(GlobalContext);
  if (!context) {
    throw new Error("GlobalContext must be used within a provider");
  }
  const { state, dispatch } = context;



  return (
    <>
         <Header value={state}/>
      {console.log("The state Product data are ", state)};
      <main className="main_conatainer">
        {state?.product?.map((data: IProducts) => {
        
          return (
            <div key={data.id} className="container">
              <img
                src={data.image}
                alt={data.title}
                className="container_image"
              />
              <h1 className="container_category">Category:{data.category}</h1>
              <p className="container_title">Title:{data.title}</p>
              <h1 className="container_price">Price:${data.price}</h1>
              <p className="container_description">
                Description:{data.description}
              </p>

              <button
                className={
                  state.whishlist.some((item:IProducts) => item.id === data.id && item.isLiked)
                    ? "container_button2"
                    : "container_button"
                }
                onClick={() =>dispatch({type:"Like_item",payload:data})}
              
              >
                Like
              </button>

              <button
                className="container_addButton"
                onClick={()=>dispatch({type:"AddTocart" ,payload:data})}
              >
                AddToCArt{" "}
              </button>
             
            </div>
          );
        })}
      </main>
    </>
  );
}
