"use client"
import {IMAGE_URL} from "@/Api/product";
import "./header.scss"
import { useContext } from "react";
import { GlobalContext } from "@/store/Globalcontext";


 


export default function Header(){

  const  Globaldata=useContext(GlobalContext);
  console.log("GlobaData",Globaldata);

    return(
        <header className="header_container">
          
        <img src={IMAGE_URL} alt="Website logo" className="header_container_logo" />
          <h1>Shooping App</h1>
        <ul className="header_container_lists">
            <li>Home</li>
            <li>Contact</li>
          
             <li>Whishlist:{Globaldata?.state.cart.length}</li>
             <li>Cart :{Globaldata?.state.whishlist.length}</li>
        </ul>
        </header>
    )
}