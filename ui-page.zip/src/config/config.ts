export class Config{
    static get BASE_URL():string{
       const url=process.env.NEXT_PUBLIC_BASE_URL;
       if(!url) throw new Error("NOT FOUNd");
       return url;
    } 

    static get PRODUCT_KEY():string{
        const aurl=process.env.NEXT_PUBLIC_URL;
        if(!aurl) throw new Error("PRoDUCT KEY NOT FOUND");
         return aurl;
    }
}