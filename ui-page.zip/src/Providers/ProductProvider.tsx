"use client"

import { ApiServices } from "../services/Services";
import { IProducts } from "@/types/IProduct";
import { Config } from "@/config/config";

export class ProductProvider extends ApiServices{
    static{
        ApiServices.init(Config.BASE_URL);
     
    }
   static async getAllProducts():Promise<IProducts[]>{
    return this.getProducts<IProducts[]>(Config.PRODUCT_KEY);
  }

   static async addProduct(data:Partial<IProducts[]>):Promise<IProducts[]>{
    return this.addProducts<IProducts[]>(Config.PRODUCT_KEY,data);
   }

   static async UpadteProduct(data:Partial<IProducts[]>):Promise<IProducts[]>{
    return this.UpdateProducts<IProducts[]>(Config.PRODUCT_KEY,data);
   }

 

}