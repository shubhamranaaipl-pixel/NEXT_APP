
"use client"


export abstract class ApiServices{
  protected  static BaseUrl:string;

  static init (baseUrl:string){
    this.BaseUrl=baseUrl;
  }
  protected static getHeaders(): HeadersInit {
    return {
      "Content-Type": "application/json",
    };
  }

   static async errorHandling<T>(response: Response):Promise<T>{
    if(!response.ok){
        const message=await response.text();
        throw new Error(message ||"Something went wrong")

    }
      return response.json() as Promise<T>;
   }

   static async getProducts<T>(endpoint:string):Promise<T>{
    const res=await fetch(`${this.BaseUrl}${endpoint}`);
    return this.errorHandling<T>(res);
  }

static async addProducts<T>(endpoint:string,id:number,data:Partial<T>):Promise<T>{
    const res=await fetch(`${this.BaseUrl}${endpoint}\ ${id}`,{
        method:"POST",
        headers:this.getHeaders(),
         body: JSON.stringify(data)
    })
    return this.errorHandling<T>(res);
 }


 static async UpdateProducts<T>(endpoint:string,data:Partial<T>):Promise<T>{
    const res=await fetch(`${this.BaseUrl}${endpoint}`,{
        method:"PUT",
        headers:this.getHeaders(),
        body:JSON.stringify(data)
    })
    return this.errorHandling<T>(res);
 }
 static async deleteProducts<T>(id:number):Promise<T>{
    const res=await fetch(`${this.BaseUrl}${id}`,{
        method:"DELETE",
        headers:this.getHeaders(),
    })
    return this.errorHandling<T>(res);
 }

}
