
"use client";
import { useEffect, useState } from "react";
import "./products.scss"

import {IProducts} from "../../types/IProduct"
import { ProductProvider } from "@/Providers/ProductProvider";


export default function Product(){

const [products,setproducts]=useState<IProducts[]>([]);



useEffect(()=>{
 ProductProvider.getAllProducts().then(setproducts)
 .catch(console.error)

},[])


    return(
        <main className="main_container">
        {products.map((product)=>(
            <div key={product?.title} className="main_container_product">
          <img src={product?.image} alt={product?.title} 
          className="main_container_product_img"/>
            <h3 className="main_container_product_title">Title:{product?.title ?? ''}</h3>
            <h2 className="main_container_product_price">Price :${product?.price}</h2>
            <h4 className="main_container_product_category">Category:{product?.category}</h4>

            <button className="main_container_product_button">Add to Cart</button>
            </div>
        ))}
        </main>
    )
}