export  const carturl="/cart";
export const homeurl="/";
export const contacturl="/contact";
export const abouturl="/about";
