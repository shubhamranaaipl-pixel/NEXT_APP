"use client"

import { useEffect, useState } from "react";
import IProducts from "@/types/IProducts";
import { API_URL } from "@/Api/product";
import "./shoping.scss";

export default function ShoppingPage(){
 const [product,setProduct]=useState<IProducts[]>([]);
 const [local,setlocal]=useState<IProducts[]>([]);
 const [cart,setCart]=useState<IProducts[]>([]);
 

 useEffect(()=>{
   const prev = localStorage.getItem("products");
   const data = prev ? JSON.parse(prev) : [];
   setlocal(data);
 },[])
 useEffect(()=>{

   const cartprev=localStorage.getItem("cart");
   const cartdata=cartprev?JSON.parse(cartprev):[];
   setCart(cartdata);
 },[])
 useEffect(()=>{
   async function FetchData(){
        const res=await fetch(API_URL);
        const data=await res.json();
        setProduct(data);
      
   }
   FetchData()
 },[])
const ClickHandle = (data: IProducts) => { 
          const isCheckProduct = local.some((option) => option?.id === data?.id);  
         
          let updatedLocal;
         if(!isCheckProduct){
         updatedLocal = [...local, {...data,isClicked:true}];
         }   
         else{
          updatedLocal=local.filter((item)=>item.id !== data.id)
         
         }  
         setProduct(prev=>prev.map(item=>
            item.id === data.id ? {...item,isClicked:!item.isClicked}:item
          ))
         localStorage.setItem("products", JSON.stringify(updatedLocal));
         setlocal(updatedLocal);        
    }
    const AddtoCart=(data:IProducts)=>{

      const dataId=cart.some((option)=>option.id===data.id);
      let Updatecart;
      if(!dataId){
      Updatecart=[...cart,{...data,count:1}]
      localStorage.setItem("cart",JSON.stringify(Updatecart));
       setCart(Updatecart);
      }else{
        const findindex=cart.findIndex((option)=>option.id == data.id);
          if(findindex!=-1){
          const value=cart[findindex].count+1;
          cart[findindex] = {...cart[findindex],count: value};
          localStorage.setItem("cart",JSON.stringify(cart));
          }
      }
    }
    return(
      <>
          
        <main className="main_conatainer">
        {product.map((data)=>
        <div key={data.id} className="container">    
       <img src={data.image} alt={data.title} className="container_image"/>
      <h1 className="container_category">Category:{data.category}</h1>
      <p className="container_title">Title:{data.title}</p>
      <h1 className="container_price">Price:${data.price}</h1>
      <p className="container_description">Description:{data.description}</p>
      <button className={data?.isClicked ? "container_button2" : "container_button"}  onClick={()=>ClickHandle(data)}>Like</button>
      <button className="container_addButton" onClick={()=>AddtoCart(data)}>Add To Cart</button>
        </div>
        )}
        </main>
</>
      
    )
}