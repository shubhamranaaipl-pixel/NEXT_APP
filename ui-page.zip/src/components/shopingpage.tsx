"use client"

import { useEffect, useState } from "react";
import IProducts from "@/types/IProducts";
import { API_URL } from "@/Api/product";
import "./shoping.scss";

export default function ShoppingPage(){
 const [product,setProduct]=useState<IProducts[]>([]);
 const [local,setlocal]=useState<IProducts[]>([]);
 

 useEffect(()=>{
   const prev = localStorage.getItem("products");
   const data = prev ? JSON.parse(prev) : [];
   setlocal(data);
  //  console.log(data);
 },[])
 useEffect(()=>{
   async function FetchData(){
        const res=await fetch(API_URL);
        const data=await res.json();
        setProduct(data);
      
   }
   FetchData()
 },[])
const ClickHandle = (data: IProducts) => { 
  // console.log(data);
    
     
          const isCheckProduct = local.some((option) => option?.id === data?.id);  
      
         if(!isCheckProduct){
            const updatedLocal = [...local, {...data,isClicked:true}];
            localStorage.setItem("products", JSON.stringify(updatedLocal));
            setlocal(updatedLocal);
         }       
         setProduct((prev) => {
          const newPrev = [...prev];
          console.log("The New Prev Array is ",newPrev)
          const index = newPrev.findIndex((option) => option?.id === data?.id);
          console.log('index',index);
          if(index !== -1){
            newPrev[index] = {...data,isClicked:true};
          }

          // console.log('newPrev',newPrev)
          return newPrev;
         })
    }
    return(
      <>
       
        <main className="main_conatainer">
       
        {product.map((data)=>
        <div key={data.id} className="container">    
       <img src={data.image} alt={data.title} className="container_image"/>
      <h1 className="container_category">Category:{data.category}</h1>
      <p className="container_title">Title:{data.title}</p>
      <h1 className="container_price">Price:${data.price}</h1>
      <p className="container_description">Description:{data.description}</p>
      <button className={data?.isClicked ? "container_button2" : "container_button"}  onClick={()=>ClickHandle(data)}>Like{data?.isClicked}</button>
        </div>
        )}
        </main>
</>
      
    )
}