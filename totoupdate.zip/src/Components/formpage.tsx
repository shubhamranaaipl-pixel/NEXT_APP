import { useEffect, useState } from "react"
import type { Todos } from "../type/ITodos";
import "./formpage.scss"
import DashBoard from "./dashborad";

export default function FormPage(){
    const [titledata,settitle]=useState("");
    const [desc,setdesc]=useState("");
    const [id,setId]=useState<number|null>(null);
    const [category,setcategory]=useState("");
    const [priority,setpriority]=useState("");
    const [deadline,setdeadline]=useState("");
    const [status,setStatus]=useState("");
      const [task, setTask] = useState<Todos[]>(() => {
    try {
      const raw = localStorage.getItem("todos");
      return raw ? (JSON.parse(raw) as Todos[]) : [];
    } catch {
      return [];
    }
  });
   const HandleData=(e:React.FormEvent)=>{
      e.preventDefault();

       const Data: Todos = {
        id: id ?? Date.now(),
        title: titledata,
        description: desc,
        category: category,
        priority: priority,
        deadline: deadline,
        status:status
    }
  if(id !== null){
    setTask((prev) =>prev.map((task) =>
        task?.id === id ? Data : task
      )
    )
  }
  else{
     setTask((prev) => [...prev, Data]);
  }
  
    setId(null)
    settitle("");
    setdesc("");
    setcategory("");
    setpriority("");
    setdeadline("");
    setStatus("");



   }


   useEffect(()=>{
       localStorage.setItem("todos", JSON.stringify(task));
   },[task])

   const DeleteData=(id:number)=>{
    const updateDate=task.filter(t=>t.id !== id);
    setTask(updateDate)
   }
   const HandlCheckBox=(id:number)=>{
        const data=task.find((t)=>t.id == id);
        console.log(data?.id);
    
        
   }
   const EditData=(data: Todos)=>{
       setId(data?.id)
      settitle(data?.title);
      setdesc(data?.description);
      setcategory(data?.category);
      setpriority(data?.priority);
      setdeadline(data?.deadline);
      setStatus(data?.status);
   }
    return(
      <>
      <DashBoard task={task}/>
        <div className="main_container">
        <h1 className="main_conatiner_heading">TODO LIST</h1>
       <form onSubmit={HandleData} className="main_container_form">
         <label>Title:</label>
        <input type="text" placeholder="Enter the Title" value={titledata} onChange={(e)=>settitle(e.target.value)} 
         className="main_container_form_inputs"/>
        <label>Description:</label>
        <input type="text" placeholder="Enter the Description" value={desc} onChange={(e)=>setdesc(e.target.value)}
        className="main_container_form_inputs"/>
        <label>Category:</label>
        <select className="main_container_form_inputs" value={category} onChange={(e)=>setcategory(e.target.value)}>
            <option value="Work">Work</option>
            <option value="Personal">Personal</option>
            <option value="Health">Health</option>
            <option value="Learning">Learning</option>
        </select>

        <label>Priority:</label>
        <select className="main_container_form_inputs" value={priority} onChange={(e)=>setpriority(e.target.value)}>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
        </select>
        <label>Deadline:</label>
        <input type="date" className="main_container_form_inputs" value={deadline} onChange={(e)=>setdeadline(e.target.value)}/>   
        
        <div className="main_container_form_status">
        <label>Status:</label>

      <label>Pending</label>
      <input type="radio" name="status" value="Pending" checked={status==="Pending"} onChange={(e)=>setStatus(e.target.value)} />

      <label>Completed</label> 
      <input type="radio" name="status" value="Complete" checked={status==="Complete"} onChange={(e)=>setStatus(e.target.value)} />
        </div>
       <button type="submit" className="main_container_form_submitbutton">Submit</button>
       </form>

      {task.length>0 && (
      
        <div className="container2">
        <h1 className="container2_heading">TASKS:{task.length}</h1>
    
        {task.map((t)=>(
           <div key={t.id} className="container2_form">
             {t.title &&<p className="container2_form_title">Title:{t?.title}</p>}
             {t.description &&<p className="container2_form_desc">Description:{t?.description}</p>}
             {t.category &&<p>Category:{t.category}</p>}
             {t.priority && <p>Priority:{t?.priority}</p>}
          
             {t.deadline &&<p className="container2_form_deadline">Deadline:{t?.deadline}</p>}
             {t.status &&<p>Status:{t?.status}</p>}
             <input type="checkbox" value="Done"  onChange={()=>HandlCheckBox(t.id)} />
             <button onClick={()=>DeleteData(t.id)} className="container2_form_deletebutton">DELETE</button>
             <button className="conatiner2_form_editbutton" onClick={()=>EditData(t)}>EDIT</button>
           </div>
        ))}
         </div>
      )}
        </div>
          </>
    )
  
}