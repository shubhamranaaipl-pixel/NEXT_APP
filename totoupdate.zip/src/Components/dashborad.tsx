
import "./dashboard.scss"
import type { Todos } from "../type/ITodos";


interface Props{
  task:Todos[]
}
export default function DashBoard({task}:Props){
   const completetask = task.filter(t=>t.status==="Complete").length;
  const pendingTask = task.filter(t => t.status === "Pending").length;
 
  

    return(
        <main className="dash_container">
          <h5 className="dash_container_heading">Total Number of Task:{task?.length}</h5>
          <h5 className="dash_container_heading">No of Complet Task:{completetask}</h5>
          <h5 className="dash_container_heading">No Of pendingTask:{pendingTask}</h5>
        </main>
    )
}