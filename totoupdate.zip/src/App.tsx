
import FormPage from "./Components/formpage"
function App() {

  return (
    <>
    
      <FormPage/>
    </>
  )
}

export default App
