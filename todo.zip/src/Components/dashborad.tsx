import { useEffect, useState } from "react"
import "./dashboard.scss"

export default function DashBoard(){
  const [task,settask]=useState<string|null>(null);
  const [completetask,setcomplete]=useState<number>(0);
  const [PendingTask,setPending]=useState<number>(0)

  useEffect(()=>{
    const val=localStorage.getItem("todos");
    const data =val ?JSON.parse(val):[]

  const complete =data.filter((t)=>t.status==="Complete").length;
  setcomplete(complete)
  
   const pending=data.filter((t)=>t.status==="Pending").length;
   setPending(pending)
    settask(data)
    
  },[])
 
  

    return(
      
        <main className="dash_container">
          <h5 className="dash_container_heading">Total Number of Task:{task?.length}</h5>
          <h5 className="dash_container_heading">No of Complet Task:{completetask}</h5>
          <h5 className="dash_container_heading">No Of pendingTask:{PendingTask}</h5>
        </main>
    )
}