import DashBoard from "./Components/dashborad"
import FormPage from "./Components/formpage"
function App() {

  return (
    <>
    <DashBoard/>
      <FormPage/>
    </>
  )
}

export default App
