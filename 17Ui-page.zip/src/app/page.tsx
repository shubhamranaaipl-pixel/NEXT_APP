import ShoppingPage from "@/components/shopingpage";
import Header from "@/components/header";

export default function Home() {
  return (
   <>
   <Header/>
   <ShoppingPage/>
   </> 
  );
}
