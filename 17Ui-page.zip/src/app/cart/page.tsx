"use client"

import IProducts from "@/types/IProducts"
import { useEffect, useState } from "react";
import "../../style/cartpage.scss";

export default function Cart(){
   const [carItem,setcartItem]=useState<IProducts[]>([]);

   useEffect(()=>{
    const data=localStorage.getItem("cart");
    const local=data?JSON.parse(data):[];
    console.log(local)
    setcartItem(local);
   },[])
  const DeleteItem=(id:number)=>{
    const updateddata=carItem.filter(item=>item.id !== id);
    setcartItem(updateddata)
  }
    return(
      <>
        <h1 className="heading">Cart Page </h1>
        <main className="cart_container"> 
          
         {carItem.map((item,index)=>
         <div key={index} className="cart_container_items">
            <img src={item.image} alt={item.title}  className="cart_container_items_image"/>
            <aside className="asidebar">
            <h1 className="cart_container_items_title">Title: {item.title}</h1>
            <h1> Itemcount:{item.count}</h1>
            <h1 className="cart_container_items_price">Pricce: ${item.price}</h1>
            </aside>
            <button onClick={()=>DeleteItem(item.id)} className="cart_container_items_button">Delete</button>
         </div>
        )}
        </main>
         </>
    )
}