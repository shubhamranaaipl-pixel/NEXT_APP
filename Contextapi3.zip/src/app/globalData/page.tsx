"use client";

import { useContext } from "react";
import { GlobalContext } from "@/store/Globalcontext";
export default function LikeItem(){

    const globaldata=useContext(GlobalContext);
    console.log(globaldata?.count)
    return (
     <>
     <h1>Hello </h1>
     
     </>
    )
}