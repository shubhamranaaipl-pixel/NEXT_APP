"use client";

import { useEffect, useState } from "react";
import IProducts from "@/types/IProducts";
import { API_URL } from "@/Api/product";
import "./shoping.scss";
import Header from "./header";
import { useContext } from "react";
import { GlobalContext } from "@/store/Globalcontext";



export default function ShoppingPage(){
 const [product,setProduct]=useState<IProducts[]>([]);
 const [local,setlocal]=useState<IProducts[]>([]);
 const [cart,setCart]=useState<IProducts[]>([]);
  
 const ClickCounter=useContext(GlobalContext);
//  console.log("The Global Count Data is",ClickCounter?.count);


 useEffect(()=>{
   const prev = localStorage.getItem("products");
   const data = prev ? JSON.parse(prev) : [];
   setlocal(data);
 },[])
 useEffect(()=>{
   const cartprev=localStorage.getItem("cart");
   const cartdata=cartprev?JSON.parse(cartprev):[];
   setCart(cartdata);
 },[])
 useEffect(()=>{
   async function FetchData(){
        const res=await fetch(API_URL);
        const data=await res.json();
        setProduct(data);  
   }
   FetchData()
 },[])
    //      const ClickHandle = (data: IProducts) => { 
    //       const isCheckProduct = local.some((option) => option?.id === data?.id);  
         
    //       let updatedLocal;
    //      if(!isCheckProduct){
    //      updatedLocal = [...local, {...data,isClicked:true}];
    //      }   
    //      else{
    //       updatedLocal=local.filter((item)=>item.id !== data.id)
         
    //      }  
    //      setProduct(prev=>prev.map(item=>
    //         item.id === data.id ? {...item,isClicked:!item.isClicked}:item
    //       ))
    //      localStorage.setItem("products", JSON.stringify(updatedLocal));
    //      setlocal(updatedLocal);        
    // }
    
   
     const AddtoCart=(data:IProducts)=>{
      const dataId=cart.some((option)=>option.id===data.id);
      let Updatecart;
      
      if(!dataId){
        Updatecart=[...cart,{...data,count:1}]
        localStorage.setItem("cart",JSON.stringify(Updatecart));
        setCart(Updatecart);
      }else{
        const findindex=cart.findIndex((option)=>option.id == data.id);
        if(findindex!=-1){
          const newCart = [...cart];
          newCart[findindex] = { ...newCart[findindex], count: newCart[findindex].count+=1 };
          localStorage.setItem("cart",JSON.stringify(newCart));
          setCart(newCart);
        }
      }  
    }

    return( 
      <>
        <Header Cart={cart}/>
        <main className="main_conatainer">
        {product.map((data)=>{
         const cartItem=cart.find(item=>item.id ===data.id);
        return(
         <div key={data.id} className="container">    
       <img src={data.image} alt={data.title} className="container_image"/>
      <h1 className="container_category">Category:{data.category}</h1>
      <p className="container_title">Title:{data.title}</p>
      <h1 className="container_price">Price:${data.price}</h1>
      <p className="container_description">Description:{data.description}</p>
     
       <button className="container_button" onClick={() => ClickCounter?.setcount([...ClickCounter?.count, { image: data.image, title: data.title,id:data.id }])}>Like</button>
      <button className="container_addButton" onClick={()=>AddtoCart(data)}>Add To Cart</button>
       <p>Count:{cartItem?cartItem.count:0}</p>
        </div>
        )}
        )}
        </main>
</>
 
    )
}

